using RepairOrders;
using RepairOrders.Implementations.Common.Enums;

namespace RepairOrdersTest
{
    [TestFixture]
    public class RepairOrderTests
    {
        #region Member Variables
       
        private RepairOrder _repairOrder;

        #endregion Member Variables

        [SetUp]

        /// <summary>
        /// Create dependencies for system under test
        /// </summary>
        public void Setup()
        {
            _repairOrder = new RepairOrder();
        }

        [Test]
        public void LargeRepairOrderForNewCustomers()
        {
            // Arrange

            #region Objects

            bool isRushOrder = false;
            OrderType orderType = OrderType.Repair;
            bool isNewCustomer = true;
            bool isLargeOrder = true;

            #endregion Objects

            // Act

            var result = _repairOrder.ProcessOrder(isRushOrder, orderType, isNewCustomer, isLargeOrder);

            // Assert
           
            Assert.IsNotNull(result);
            Assert.That(result, Is.EqualTo(OrderStatus.Closed));
        }

        [Test]
        public void LargeRushHireOrder()
        {
            // Arrange

            #region Objects

            bool isRushOrder = true;
            OrderType orderType = OrderType.Hire;
            bool isNewCustomer = false;
            bool isLargeOrder = true;

            #endregion Objects

            // Act

            var result = _repairOrder.ProcessOrder(isRushOrder, orderType, isNewCustomer, isLargeOrder);

            // Assert

            Assert.IsNotNull(result);
            Assert.That(result, Is.EqualTo(OrderStatus.Closed));
        }

        [Test]
        public void LargeRepairOrder()
        {
            // Arrange

            #region Objects

            bool isRushOrder = false;
            OrderType orderType = OrderType.Repair;
            bool isNewCustomer = false;
            bool isLargeOrder = true;

            #endregion Objects

            // Act

            var result = _repairOrder.ProcessOrder(isRushOrder, orderType, isNewCustomer, isLargeOrder);

            // Assert

            Assert.IsNotNull(result);
            Assert.That(result, Is.EqualTo(OrderStatus.AuthorisationRequired));
        }

        [Test]
        public void RushOrderForNewCustomers()
        {
            // Arrange

            #region Objects

            bool isRushOrder = true;
            OrderType orderType = OrderType.Repair;
            bool isNewCustomer = true;
            bool isLargeOrder = false;

            #endregion Objects

            // Act

            var result = _repairOrder.ProcessOrder(isRushOrder, orderType, isNewCustomer, isLargeOrder);

            // Assert

            Assert.IsNotNull(result);
            Assert.That(result, Is.EqualTo(OrderStatus.AuthorisationRequired));
        }

        [Test]
        public void AllOrders()
        {
            // Arrange

            #region Objects

            bool isRushOrder = false;
            OrderType orderType = OrderType.Repair;
            bool isNewCustomer = false;
            bool isLargeOrder = false;

            #endregion Objects

            // Act

            var result = _repairOrder.ProcessOrder(isRushOrder, orderType, isNewCustomer, isLargeOrder);

            // Assert

            Assert.IsNotNull(result);
            Assert.That(result, Is.EqualTo(OrderStatus.Confirmed));
        }
    }
}