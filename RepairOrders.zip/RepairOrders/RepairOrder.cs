﻿using RepairOrders.Implementations.Common.Enums;
using RepairOrders.Implementations.Constraints;

namespace RepairOrders
{
    /// <summary>
    /// This class is responsible to deal with any new repair order processing
    /// </summary>
    public class RepairOrder
    {
        /// <summary>
        /// This method processes new repair order
        /// </summary>
        /// <param name="isRushOrder">bool</param>
        /// <param name="orderType">Enum (Repair, Hire)</param>
        /// <param name="isNewCustomer">bool</param>
        /// <param name="isLargeOrder">bool</param>
        /// <returns>enum OrderStatus - "Confirmed", "Closed" or "AuthorisationRequired"</returns>
        public OrderStatus ProcessOrder(bool isRushOrder, OrderType orderType,bool isNewCustomer, bool isLargeOrder)
        {
            var constraint = new LargeRepairOrderForNewCustomerConstraint(new LargeRushHireOrderConstraint(new LargeRepairOrderConstraint(new RushOrderForNewCustomersConstraint(new DefaultConstraint(null)))));
            var status = constraint.ApplyConstraint(isRushOrder, orderType, isNewCustomer, isLargeOrder);
            return status;
        }
    }
}
