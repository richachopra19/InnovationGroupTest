﻿using RepairOrders.Implementations.Common.Enums;
using RepairOrders.Implementations.Interfaces;

namespace RepairOrders.Implementations.Constraints
{
    /// <summary>
    /// This is default constraint class
    /// </summary>
    public class DefaultConstraint : IConstraint
    {
        #region Member Variables

        public IConstraint nextConstraint;

        #endregion Member Variables

        /// <summary>
        /// Construct my DefaultConstraint
        /// </summary>
        /// <param name="nextConstraint">a concrete class that implements the RepairOrders.Implementations.Interfaces.IConstraint interface</param>
        public DefaultConstraint(IConstraint nextConstraint)
        {
            this.nextConstraint = nextConstraint;
        }

        /// <summary>
        /// this is a method to apply constraint for all orders
        /// </summary>
        /// <param name="isRushOrder">bool</param>
        /// <param name="orderType">Enum (Repair, Hire)</param>
        /// <param name="isNewCustomer">bool</param>
        /// <param name="isLargeOrder">bool</param>
        /// <returns>enum OrderStatus - "Confirmed", "Closed" or "AuthorisationRequired"</returns>
        public OrderStatus ApplyConstraint(bool isRushOrder, OrderType orderType, bool isNewCustomer, bool isLargeOrder)
        {
            //All other orders should be confirmed
            OrderStatus status = OrderStatus.Confirmed;
            return status;
        }
    }
}
