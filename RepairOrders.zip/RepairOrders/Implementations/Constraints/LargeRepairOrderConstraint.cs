﻿using RepairOrders.Implementations.Common.Enums;
using RepairOrders.Implementations.Interfaces;

namespace RepairOrders.Implementations.Constraints
{
    /// <summary>
    /// This is a Constraint class for  LargeRepairOrderConstraint
    /// </summary>
    public class LargeRepairOrderConstraint : IConstraint
    {
        #region Member Variables

        public IConstraint nextConstraint;

        #endregion Member Variables

        #region Constructor

        /// <summary>
        /// Construct my LargeRepairOrderConstraint
        /// </summary>
        /// <param name="nextConstraint">a concrete class that implements the RepairOrders.Implementations.Interfaces.IConstraint interface</param>
        public LargeRepairOrderConstraint(IConstraint nextConstraint)
        {
            this.nextConstraint = nextConstraint;
        }

        #endregion Constructor

        #region Process

        /// <summary>
        /// this is a method to apply constraint for LargeRepairOrders
        /// </summary>
        /// <param name="isRushOrder">bool</param>
        /// <param name="orderType">Enum (Repair, Hire)</param>
        /// <param name="isNewCustomer">bool</param>
        /// <param name="isLargeOrder">bool</param>
        /// <returns>enum OrderStatus - "Confirmed", "Closed" or "AuthorisationRequired"</returns>
        public OrderStatus ApplyConstraint(bool isRushOrder, OrderType orderType, bool isNewCustomer, bool isLargeOrder)
        {
            //By default order status is confirmed
            OrderStatus status = OrderStatus.Confirmed;

            //Large repair orders always require authorisation
            if (isLargeOrder && orderType == OrderType.Repair)
            {
                status = OrderStatus.AuthorisationRequired;
            }
            else
            {
                //Move to next constraint
                if (nextConstraint != null) { status = nextConstraint.ApplyConstraint(isRushOrder, orderType, isNewCustomer, isLargeOrder); }
            }
                return status;
        }

        #endregion Process
    }
}
