﻿using RepairOrders.Implementations.Common.Enums;
using RepairOrders.Implementations.Interfaces;

namespace RepairOrders.Implementations.Constraints
{
    /// <summary>
    /// This is a Constraint class for  RushOrderForNewCustomersConstraint
    /// </summary>
    public class RushOrderForNewCustomersConstraint : IConstraint
    {
        #region Member Variables

        public IConstraint nextConstraint;

        #endregion Member Variables

        #region Constructor

        /// <summary>
        /// Construct my RushOrderForNewCustomersConstraint
        /// </summary>
        /// <param name="nextConstraint">a concrete class that implements the RepairOrders.Implementations.Interfaces.IConstraint interface</param>
        public RushOrderForNewCustomersConstraint(IConstraint nextConstraint)
        {
            this.nextConstraint = nextConstraint;
        }
        #endregion Constructor

        #region Process

        /// <summary>
        /// this is a method to apply constraint for RushOrderForNewCustomers
        /// </summary>
        /// <param name="isRushOrder">bool</param>
        /// <param name="orderType">Enum (Repair, Hire)</param>
        /// <param name="isNewCustomer">bool</param>
        /// <param name="isLargeOrder">bool</param>
        /// <returns>enum OrderStatus - "Confirmed", "Closed" or "AuthorisationRequired"</returns>
        public OrderStatus ApplyConstraint(bool isRushOrder, OrderType orderType, bool isNewCustomer, bool isLargeOrder)
        {
            //By default order status is confirmed
            OrderStatus status = OrderStatus.Confirmed;

            // All rush orders for new customers always require authorisation
            if (isRushOrder && isNewCustomer)
            {
                status = OrderStatus.AuthorisationRequired;
            }
            else
            {
                // Move to next constraint
                if (nextConstraint != null) { status = nextConstraint.ApplyConstraint(isRushOrder, orderType, isNewCustomer, isLargeOrder); }
            }
                return status;
        }

        #endregion Process

    }
}
