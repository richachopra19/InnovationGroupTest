﻿
using RepairOrders.Implementations.Common.Enums;

namespace RepairOrders.Implementations.Interfaces
{
    /// <summary>
    /// This is interface class for constraint that all concrete classes will implement to define constraint
    /// </summary>
    public interface IConstraint
    {
        #region Process

        /// <summary>
        /// This is a method to apply constraint
        /// </summary>
        /// <param name="isRushOrder">bool</param>
        /// <param name="orderType">Enum (Repair, Hire)</param>
        /// <param name="isNewCustomer">bool</param>
        /// <param name="isNewOrder">bool</param>
        /// <returns>enum OrderStatus - "Confirmed", "Closed" or "AuthorisationRequired"</returns>
        OrderStatus ApplyConstraint(bool isRushOrder, OrderType orderType, bool isNewCustomer, bool isLargeOrder);

        #endregion Process
    }
}
