﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairOrders.Implementations.Common.Enums
{
    /// <summary>
    /// Enum for Order type
    /// </summary>
    public enum OrderType
    {
        [Description("Repair")]
        Repair = 1,
        [Description("Hire")]
        Hire = 2,
    }
}
