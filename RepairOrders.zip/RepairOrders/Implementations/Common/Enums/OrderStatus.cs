﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RepairOrders.Implementations.Common.Enums
{
    /// <summary>
    /// Enum for Order status
    /// </summary>
    public enum OrderStatus
    {
        [Description("Confirmed")]
        Confirmed = 1,
        [Description("Closed")]
        Closed = 2,
        [Description("AuthorisationRequired")]
        AuthorisationRequired = 3,
    }
}
