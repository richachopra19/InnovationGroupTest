﻿// See https://aka.ms/new-console-template for more information


using RepairOrders;
using RepairOrders.Implementations.Common.Enums;
using System;

#region Inputs

bool isRushOrder = true;
OrderType orderType = OrderType.Repair;
bool isNewCustomer = true;
bool isLargeOrder = true;

#endregion Inputs

//Outputs:
//OrderStatus: Enum(Confirmed, Closed, AuthorisationRequired)

//Requirements(Applied in priority order from top to bottom):
//-Large repair orders for new customers should be closed
//-Large rush hire orders should always be closed
//-Large repair orders always require authorisation
//-All rush orders for new customers always require authorisation
//-All other orders should be confirmed

#region Process

// Process new repair order
RepairOrder order = new RepairOrder();
var status = order.ProcessOrder(isRushOrder, orderType, isNewCustomer, isLargeOrder);
Console.WriteLine(status);

#endregion Process


